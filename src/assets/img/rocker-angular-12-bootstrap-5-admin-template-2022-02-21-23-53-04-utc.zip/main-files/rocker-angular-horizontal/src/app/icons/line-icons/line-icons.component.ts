import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-line-icons',
  templateUrl: './line-icons.component.html',
  styleUrls: ['./line-icons.component.scss']
})
export class LineIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
