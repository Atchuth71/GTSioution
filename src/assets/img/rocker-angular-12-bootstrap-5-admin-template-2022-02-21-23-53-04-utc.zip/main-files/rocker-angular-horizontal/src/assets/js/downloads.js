$(document).ready(function() {
    $('#Download-pagination').DataTable({
        lengthMenu: [[8, 10, 20, -1], [8, 10, 20, 'Todos']]
    });
  } );
  